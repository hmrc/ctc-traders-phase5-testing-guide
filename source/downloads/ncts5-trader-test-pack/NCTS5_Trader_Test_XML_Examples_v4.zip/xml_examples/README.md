# NCTS5 Trader Test pack - XML files

## About the XML files

The files in this zip file contain example XML messages - one message for each test scenario in the [CTC Traders API phase 5 testing guide](https://developer.service.hmrc.gov.uk/guides/ctc-traders-phase5-testing-guide/). The XML files are provided only as examples and may contain optional data. They are not intended to be prescriptive.

## Version history

### Changes made on 9 October 2023 for transition rules testing

The following changes have been made to the example XML files:

- removed examples for test scenarios DSGB3, DNGB3, DSXI3, and DNXI3 because the functionality that they demonstrate will be available only when NCTS5 Trader Test is running in NCTS5 final mode
- removed `Place of Loading` data group
- changed `NCTS PhaseID` from `5.0` to `5.1`
- changed `Gross mass` and `Net mass` figures to 3 decimals
- changed `Amount to be covered` to 2 decimals

### standard-departures

#### gb-xi

##### normal

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `dngb1_ie015_xml_example.xml` | 16/05/23 | 9/11/23 | See changes made on 9/10/23 for transition rules testing |
| `dngb2_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| ~~`dngb3_ie015_xml_example.xml`~~ | 16/05/23 | 9/10/23 | Corresponding test scenario has been removed until NCTS5 Trader Test moves to NCTS5 final mode. |
| `dngb4_ie014_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dngb4_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dngb5_ie014_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dngb5_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dngb6_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dngb7_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dngb8_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dngb9_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dngb10_ie013_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dngb10_ie015_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |

##### simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `dsgb1_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsgb2_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| ~~`dsgb3_ie015_xml_example.xml`~~ | 16/05/23 | 9/10/23 | Corresponding test scenario has been removed until NCTS5 Trader Test moves to NCTS5 final mode. |
| `dsgb4_ie014_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsgb4_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsgb5_ie014_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsgb5_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsgb6_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsgb7_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsgb8_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsgb9_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsgb10_ie013_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsgb10_ie015_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |

#### xi-gb

##### normal

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `dnxi1_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dnxi2_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| ~~`dnxi3_ie015_xml_example.xml`~~ | 16/05/23 | 9/10/23 | Corresponding test scenario has been removed until NCTS5 Trader Test moves to NCTS5 final mode. |
| `dnxi4_ie014_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dnxi4_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dnxi5_ie014_xml_example.xml` | 16/05/23 | 9/10/23 |See changes made on 9/10/23 for transition rules testing |
| `dnxi5_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dnxi6_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dnxi7_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dnxi8_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dnxi9_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dnxi10_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dnxi11_ie013_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dnxi11_ie015_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |

##### simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `dsxi1_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsxi2_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| ~~`dsxi3_ie015_xml_example.xml`~~ | 16/05/23 | 9/10/23 | Corresponding test scenario has been removed until NCTS5 Trader Test moves to NCTS5 final mode. |
| `dsxi4_ie014_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsxi4_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsxi5_ie014_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsxi5_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsxi6_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsxi7_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsxi7_ie015_xml_example.xml` | 16/05/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsxi8_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsxi9_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsxi10_ie013_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `dsxi10_ie015_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |

### prelodged-departures

#### gb-xi

##### normal

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `pngb1_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `pngb1_ie170_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `pngb2_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `pngb2_ie170_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `pngb3_ie013_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `pngb3_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `pngb3_ie170_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `pngb4_ie014_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `pngb4_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |

##### simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `psgb1_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `psgb1_ie170_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `psgb2_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `psgb2_ie170_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `psgb3_ie013_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `psgb3_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `psgb3_ie170_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `psgb4_ie014_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `psgb4_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |

#### xi-gb

##### normal

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `pnxi1_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `pnxi1_ie170_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `pnxi2_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `pnxi2_ie170_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `pnxi3_ie013_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `pnxi3_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `pnxi3_ie170_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `pnxi4_ie014_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `pnxi4_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |

##### simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `psxi1_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `psxi1_ie170_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `psxi2_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `psxi2_ie170_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `psxi3_ie013_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `psxi3_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `psxi3_ie170_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `psxi4_ie014_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `psxi4_ie015_xml_example.xml` | 5/07/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |

### arrivals

#### gb-xi

##### normal

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `angb1_ie007_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `angb1_ie015_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |

##### normal-simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `agb1_ie007_simplified_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `agb1_ie015_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |

##### simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `asgb1_ie007_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asgb1_ie015_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asgb1_ie044_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asgb2_ie007_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asgb2_ie015_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asgb2_ie044_invalid_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asgb2_ie044_valid_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asgb3_ie007_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asgb3_ie015_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asgb3_ie044_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asgb4_ie007_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asgb4_ie015_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asgb4_ie044_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |

#### xi-gb

##### normal

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `anxi1_ie007_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `anxi1_ie015_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |

##### normal-simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `axi1_ie007_simplified_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `axi1_ie015_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |

##### simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `asxi1_ie007_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asxi1_ie015_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asxi1_ie044_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asxi2_ie007_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asxi2_ie015_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asxi2_ie044_invalid_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asxi2_ie044_valid_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asxi3_ie007_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asxi3_ie015_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asxi3_ie044_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asxi4_ie007_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asxi4_ie015_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |
| `asxi4_ie044_xml_example.xml` | 3/08/23 | 9/10/23 | See changes made on 9/10/23 for transition rules testing |