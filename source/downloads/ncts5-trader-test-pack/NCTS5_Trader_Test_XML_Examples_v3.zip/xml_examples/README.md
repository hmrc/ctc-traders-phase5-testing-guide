# NCTS5 Trader Test pack - XML files

## About the XML files

The files in this zip file contain example XML messages - one message for each test scenario in the [CTC Traders API phase 5 testing guide](https://developer.service.hmrc.gov.uk/guides/ctc-traders-phase5-testing-guide/). The XML files are provided only as examples and may contain optional data. They are not intended to be prescriptive.

## Version history

### standard-departures

#### gb-xi

##### normal

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `dngb1_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dngb2_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dngb3_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dngb4_ie014_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dngb4_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dngb5_ie014_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dngb5_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dngb6_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dngb7_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dngb8_ie015_xml_example.xml` | 5/07/23 |  |  |
| `dngb9_ie015_xml_example.xml` | 5/07/23 |  |  |
| `dngb10_ie013_xml_example.xml` | 3/08/23 | | |
| `dngb10_ie015_xml_example.xml` | 3/08/23 | | |

##### simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `dsgb1_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dsgb2_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dsgb3_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dsgb4_ie014_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dsgb4_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dsgb5_ie014_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dsgb5_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dsgb6_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dsgb7_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.GB` |
| `dsgb8_ie015_xml_example.xml` | 5/07/23 |  |  |
| `dsgb9_ie015_xml_example.xml` | 5/07/23 |  |  |
| `dsgb10_ie013_xml_example.xml` | 3/08/23 | | |
| `dsgb10_ie015_xml_example.xml` | 3/08/23 | | |

#### xi-gb

##### normal

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `dnxi1_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dnxi2_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dnxi3_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dnxi4_ie014_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dnxi4_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dnxi5_ie014_xml_example.xml` | 16/05/23 | 5/07/23 |Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dnxi5_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dnxi6_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dnxi7_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dnxi8_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dnxi9_ie015_xml_example.xml` | 5/07/23 |  |  |
| `dnxi10_ie015_xml_example.xml` | 5/07/23 |  |  |
| `dnxi11_ie013_xml_example.xml` | 3/08/23 | | |
| `dnxi11_ie015_xml_example.xml` | 3/08/23 | | |

##### simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `dsxi1_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dsxi2_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dsxi3_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dsxi4_ie014_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dsxi4_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dsxi5_ie014_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dsxi5_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dsxi6_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dsxi7_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dsxi7_ie015_xml_example.xml` | 16/05/23 | 5/07/23 | Change value of `messageRecipient` from `NCTS` to `NTA.XI` |
| `dsxi8_ie015_xml_example.xml` | 5/07/23 |  |  |
| `dsxi9_ie015_xml_example.xml` | 5/07/23 |  |  |
| `dsxi10_ie013_xml_example.xml` | 3/08/23 | | |
| `dsxi10_ie015_xml_example.xml` | 3/08/23 | | |

### prelodged-departures

#### gb-xi

##### normal

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `pngb1_ie015_xml_example.xml` | 5/07/23 |  |  |
| `pngb1_ie170_xml_example.xml` | 5/07/23 |  |  |
| `pngb2_ie015_xml_example.xml` | 5/07/23 |  |  |
| `pngb2_ie170_xml_example.xml` | 5/07/23 |  |  |
| `pngb3_ie013_xml_example.xml` | 5/07/23 |  |  |
| `pngb3_ie015_xml_example.xml` | 5/07/23 |  |  |
| `pngb3_ie170_xml_example.xml` | 5/07/23 |  |  |
| `pngb4_ie014_xml_example.xml` | 5/07/23 |  |  |
| `pngb4_ie015_xml_example.xml` | 5/07/23 |  |  |

##### simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `psgb1_ie015_xml_example.xml` | 5/07/23 |  |  |
| `psgb1_ie170_xml_example.xml` | 5/07/23 |  |  |
| `psgb2_ie015_xml_example.xml` | 5/07/23 |  |  |
| `psgb2_ie170_xml_example.xml` | 5/07/23 |  |  |
| `psgb3_ie013_xml_example.xml` | 5/07/23 |  |  |
| `psgb3_ie015_xml_example.xml` | 5/07/23 |  |  |
| `psgb3_ie170_xml_example.xml` | 5/07/23 |  |  |
| `psgb4_ie014_xml_example.xml` | 5/07/23 |  |  |
| `psgb4_ie015_xml_example.xml` | 5/07/23 |  |  |

#### xi-gb

##### normal

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `pnxi1_ie015_xml_example.xml` | 5/07/23 |  |  |
| `pnxi1_ie170_xml_example.xml` | 5/07/23 |  |  |
| `pnxi2_ie015_xml_example.xml` | 5/07/23 |  |  |
| `pnxi2_ie170_xml_example.xml` | 5/07/23 |  |  |
| `pnxi3_ie013_xml_example.xml` | 5/07/23 |  |  |
| `pnxi3_ie015_xml_example.xml` | 5/07/23 |  |  |
| `pnxi3_ie170_xml_example.xml` | 5/07/23 |  |  |
| `pnxi4_ie014_xml_example.xml` | 5/07/23 |  |  |
| `pnxi4_ie015_xml_example.xml` | 5/07/23 |  |  |

##### simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `psxi1_ie015_xml_example.xml` | 5/07/23 |  |  |
| `psxi1_ie170_xml_example.xml` | 5/07/23 |  |  |
| `psxi2_ie015_xml_example.xml` | 5/07/23 |  |  |
| `psxi2_ie170_xml_example.xml` | 5/07/23 |  |  |
| `psxi3_ie013_xml_example.xml` | 5/07/23 |  |  |
| `psxi3_ie015_xml_example.xml` | 5/07/23 |  |  |
| `psxi3_ie170_xml_example.xml` | 5/07/23 |  |  |
| `psxi4_ie014_xml_example.xml` | 5/07/23 |  |  |
| `psxi4_ie015_xml_example.xml` | 5/07/23 |  |  |

### arrivals

#### gb-xi

##### normal

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `angb1_ie007_xml_example.xml` | 3/08/23 |  |  |
| `angb1_ie015_xml_example.xml` | 3/08/23 |  |  |

##### normal-simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `agb1_ie007_simplified_xml_example.xml` | 3/08/23 |  |  |
| `agb1_ie015_xml_example.xml` | 3/08/23 |  |  |

##### simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `asgb1_ie007_xml_example.xml` | 3/08/23 |  |  |
| `asgb1_ie015_xml_example.xml` | 3/08/23 |  |  |
| `asgb1_ie044_xml_example.xml` | 3/08/23 |  |  |
| `asgb2_ie007_xml_example.xml` | 3/08/23 |  |  |
| `asgb2_ie015_xml_example.xml` | 3/08/23 |  |  |
| `asgb2_ie044_invalid_xml_example.xml` | 3/08/23 |  |  |
| `asgb2_ie044_valid_xml_example.xml` | 3/08/23 |  |  |
| `asgb3_ie007_xml_example.xml` | 3/08/23 |  |  |
| `asgb3_ie015_xml_example.xml` | 3/08/23 |  |  |
| `asgb3_ie044_xml_example.xml` | 3/08/23 |  |  |
| `asgb4_ie007_xml_example.xml` | 3/08/23 |  |  |
| `asgb4_ie015_xml_example.xml` | 3/08/23 |  |  |
| `asgb4_ie044_xml_example.xml` | 3/08/23 |  |  |

#### xi-gb

##### normal

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `anxi1_ie007_xml_example.xml` | 3/08/23 |  |  |
| `anxi1_ie015_xml_example.xml` | 3/08/23 |  |  |

##### normal-simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `axi1_ie007_simplified_xml_example.xml` | 3/08/23 |  |  |
| `axi1_ie015_xml_example.xml` | 3/08/23 |  |  |

##### simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `asxi1_ie007_xml_example.xml` | 3/08/23 |  |  |
| `asxi1_ie015_xml_example.xml` | 3/08/23 |  |  |
| `asxi1_ie044_xml_example.xml` | 3/08/23 |  |  |
| `asxi2_ie007_xml_example.xml` | 3/08/23 |  |  |
| `asxi2_ie015_xml_example.xml` | 3/08/23 |  |  |
| `asxi2_ie044_invalid_xml_example.xml` | 3/08/23 |  |  |
| `asxi2_ie044_valid_xml_example.xml` | 3/08/23 |  |  |
| `asxi3_ie007_xml_example.xml` | 3/08/23 |  |  |
| `asxi3_ie015_xml_example.xml` | 3/08/23 |  |  |
| `asxi3_ie044_xml_example.xml` | 3/08/23 |  |  |
| `asxi4_ie007_xml_example.xml` | 3/08/23 |  |  |
| `asxi4_ie015_xml_example.xml` | 3/08/23 |  |  |
| `asxi4_ie044_xml_example.xml` | 3/08/23 |  |  |