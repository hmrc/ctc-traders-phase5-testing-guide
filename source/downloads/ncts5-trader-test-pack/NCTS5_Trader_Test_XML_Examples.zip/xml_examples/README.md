# NCTS5 Trader Test pack - XML files

## About the XML files

The files in this zip file contain example XML messages - one message for each test scenario in the [CTC Traders API phase 5 testing guide](https://developer.service.hmrc.gov.uk/guides/ctc-traders-phase5-testing-guide/). The XML files are provided only as examples and may contain optional data. They are not intended to be prescriptive.

## Version history

### gb-xi

#### normal

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `dngb1_ie015_xml_example.xml` | 16/05/23 | | |
| `dngb2_ie015_xml_example.xml` | 16/05/23 | | |
| `dngb3_ie015_xml_example.xml` | 16/05/23 | | |
| `dngb4_ie014_xml_example.xml` | 16/05/23 | | |
| `dngb4_ie015_xml_example.xml` | 16/05/23 | | |
| `dngb5_ie014_xml_example.xml` | 16/05/23 | | |
| `dngb5_ie015_xml_example.xml` | 16/05/23 | | |
| `dngb6_ie015_xml_example.xml` | 16/05/23 | | |
| `dngb7_ie015_xml_example.xml` | 16/05/23 | | |

#### simplified

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `dsgb1_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dsgb2_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dsgb3_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dsgb4_ie014_xml_example.xml` | 16/05/23 |  |  |
| `dsgb4_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dsgb5_ie014_xml_example.xml` | 16/05/23 |  |  |
| `dsgb5_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dsgb6_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dsgb7_ie015_xml_example.xml` | 16/05/23 |  |  |

### xi-gb

#### normal

| File name | Date first published | Date last revised | Change |
| --------- | -------------------- | ----------------- | ------ |
| `dnxi1_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dnxi2_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dnxi3_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dnxi4_ie014_xml_example.xml` | 16/05/23 |  |  |
| `dnxi4_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dnxi5_ie014_xml_example.xml` | 16/05/23 |  |  |
| `dnxi5_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dnxi6_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dnxi7_ie015_xml_example.xml` | 16/05/23 |  |	 |
| `dnxi8_ie015_xml_example.xml` | 16/05/23 |  |	 |

#### simplified

| File name | Date first published | Date last revised | Change | 
| --------- | -------------------- | ----------------- | ------ |
| `dsxi1_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dsxi2_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dsxi3_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dsxi4_ie014_xml_example.xml` | 16/05/23 |  |  |
| `dsxi4_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dsxi5_ie014_xml_example.xml` | 16/05/23 |  |  |
| `dsxi5_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dsxi6_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dsxi7_ie015_xml_example.xml` | 16/05/23 |  |  |
| `dsxi7_ie015_xml_example.xml` | 16/05/23 |  |	 |